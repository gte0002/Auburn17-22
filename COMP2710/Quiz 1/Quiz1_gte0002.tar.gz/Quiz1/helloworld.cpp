//Gabriel Emerson
//Quiz1
//Describe source code
//received any help?

#include <iostream>
using namespace std;

int main() 
{
    cout << "Hello, World!";
    cout << endl;
    return 0;
}
