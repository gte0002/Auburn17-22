### PCAP Data
A good resource for PCAP data is : [https://wiki.wireshark.org/SampleCaptures]()

- #### http.pcap:
A simple HTTP request and response
 
- #### nb6-http.pcap:
provided by french ISP SFR, there are three different HTTP requests: first was sent on the private IPv4 network (IPoE), second was sent on the public IPv4 network, third was sent on the public IPv6 network (L2TP tunnel).

