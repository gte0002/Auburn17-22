
API Reference
=============
The dpkt API reference section is currently a work in progress, please have patience as we fill in and improve the documentation.

**dpkt Modules**

.. toctree::
    :maxdepth: 4

    api_auto
